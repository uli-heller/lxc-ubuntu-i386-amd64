#!/bin/bash

exec ../speed/benchmark.bash
