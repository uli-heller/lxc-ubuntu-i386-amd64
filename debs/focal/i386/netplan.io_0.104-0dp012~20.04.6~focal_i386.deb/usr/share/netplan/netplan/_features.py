# Generated file
NETPLAN_FEATURE_FLAGS = [
    "generate-just-in-time",
    "generated-supplicant",
    "dbus-config",
    "default-routes",
    "auth-phase2",
    "dhcp-use-domains",
    "ipv6-mtu",
    "modems",
    "sriov",
    "openvswitch",
    "activation-mode",
    "eswitch-mode",
]
