/* Run the submit benchmark. */

#ifndef SUBMIT_H_
#define SUBMIT_H_

#include "report.h"

/* Run the submit subcommand. */
int SubmitRun(int argc, char *argv[], struct report *report);

#endif /* SUBMIT_H_ */
