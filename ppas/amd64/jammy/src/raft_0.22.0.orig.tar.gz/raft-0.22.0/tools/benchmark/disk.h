/* Run the disk benchmark. */

#ifndef DISK_H_
#define DISK_H_

#include "report.h"

/* Run the disk subcommand. */
int DiskRun(int argc, char *argv[], struct report *report);

#endif /* DISK_H_ */
