.. _api:

API reference
=============

.. toctree::
   :maxdepth: 1

   server
   fsm
   io
