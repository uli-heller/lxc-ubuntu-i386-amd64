#include "../lib/runner.h"

RUNNER("core")
