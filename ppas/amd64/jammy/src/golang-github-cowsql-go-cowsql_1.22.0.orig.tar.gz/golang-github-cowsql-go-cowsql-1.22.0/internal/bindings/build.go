package bindings

/*
#cgo linux LDFLAGS: -lcowsql
*/
import "C"

// required cowsql version
var cowsqlMajorVersion int = 1
var cowsqlMinorVersion int = 14
