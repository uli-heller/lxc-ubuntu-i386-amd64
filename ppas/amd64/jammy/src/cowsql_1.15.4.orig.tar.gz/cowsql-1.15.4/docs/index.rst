cowsql
======

Embeddable, replicated and fault tolerant SQL engine.
