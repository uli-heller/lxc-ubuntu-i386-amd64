
```
podman-compose run --rm sleep /bin/sh -c 'wget -O - http://web:8000/hosts'
```
