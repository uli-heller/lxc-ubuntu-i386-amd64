# Test podman-compose with build.additional_contexts

```
podman-compose build
podman-compose up
podman-compose down
```

expected output would be

```
[dict] | Data for dict
[list] | Data for list
```
