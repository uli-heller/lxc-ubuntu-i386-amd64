# to test create the two external volumes

```
podman volume create my-app-data
podman volume create actual-name-of-volume
podman-compose up 
```

