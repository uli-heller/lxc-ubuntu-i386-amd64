running the following command should give myval2

```
podman_compose run -l monkey -e ZZVAR1=myval2 env-test
```
