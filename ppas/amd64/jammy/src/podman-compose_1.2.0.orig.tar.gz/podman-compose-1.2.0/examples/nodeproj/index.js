#! /usr/bin/env node
"use strict";
import {start} from "./lib";

start();

