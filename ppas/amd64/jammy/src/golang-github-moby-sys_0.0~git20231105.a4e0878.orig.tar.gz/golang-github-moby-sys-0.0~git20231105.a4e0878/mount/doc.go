// Package mount provides a set of functions to mount and unmount mounts.
//
// Currently it supports Linux. For historical reasons, there is also some support for FreeBSD.
package mount
