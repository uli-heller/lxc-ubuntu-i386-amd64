When CLASSPATH is set to the fixtures/java/a dir, we do *not* expect
*.class in subdirs to be included in completions, see Debian bug #496828.
