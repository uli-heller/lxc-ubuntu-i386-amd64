package BashCompletionModule;
use strict;
use warnings;
1;
