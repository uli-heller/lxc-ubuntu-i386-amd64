---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Describe the feature/solution

<!-- A clear and concise description of what you want to happen. -->

## Maintenance (please complete the following information)

<!--
     See CONTRIBUTING.md, many of the considerations for new completions
     applies here, too. If upstream has been asked if they'd be interested in
     shipping the completion instead of us here in bash-completion, include
     link to the upstream query/issue below.
-->

- [ ] This is a request for new completion
- [ ] Link to upstream project query about shipping the completion:
