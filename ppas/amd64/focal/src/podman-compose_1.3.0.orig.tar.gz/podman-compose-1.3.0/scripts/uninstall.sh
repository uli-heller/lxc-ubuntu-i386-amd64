#!/usr/bin/env bash
pip3 uninstall podman-compose -y
./scripts/clean_up.sh
