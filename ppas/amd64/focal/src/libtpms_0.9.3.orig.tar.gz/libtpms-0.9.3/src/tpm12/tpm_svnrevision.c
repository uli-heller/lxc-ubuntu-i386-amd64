const unsigned short tpm_svn_revision = 4766;
