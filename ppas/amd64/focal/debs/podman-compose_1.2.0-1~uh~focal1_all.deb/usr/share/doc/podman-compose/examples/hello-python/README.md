# Simple Python Demo
## A Redis counter

```
podman-compose up -d
curl localhost:8080/
curl localhost:8080/hello.json
```
